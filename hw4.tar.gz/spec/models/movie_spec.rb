
require 'spec_helper'
describe Movie do
  
  it 'should do all movie model operations' do
    assert true
  end
  
end